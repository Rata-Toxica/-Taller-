#include <Wire.h>
#include <LiquidCrystal_I2C.h>

/*
  Sistema de monitoreo de humedad
  y recomendacion de riego.

  El potenciometro simula el sensor
  de humedad del suelo.
*/

const int PIN_SENSOR_HUMEDAD = 34;
const int PIN_RELE = 26;
const int UMBRAL_HUMEDAD = 2500;

// Direccion I2C 0x27, pantalla de 16 columnas y 2 filas
LiquidCrystal_I2C lcd(0x27, 16, 2);

void setup() {
  Serial.begin(115200);

  pinMode(PIN_SENSOR_HUMEDAD, INPUT);
  pinMode(PIN_RELE, OUTPUT);

  // El rele de la simulacion se activa con LOW
  digitalWrite(PIN_RELE, HIGH);

  // Pines I2C del ESP32
  Wire.begin(21, 22);

  lcd.init();
  lcd.backlight();
  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print("Sistema iniciado");

  lcd.setCursor(0, 1);
  lcd.print("Midiendo...");

  Serial.println("Sistema de monitoreo iniciado");

  delay(1500);
  lcd.clear();
}

void loop() {
  int humedad = analogRead(PIN_SENSOR_HUMEDAD);

  Serial.print("Lectura de humedad: ");
  Serial.println(humedad);

  // Primera linea de la pantalla
  lcd.setCursor(0, 0);
  lcd.print("Humedad: ");
  lcd.print(humedad);
  lcd.print("    ");

  // Segunda linea de la pantalla
  lcd.setCursor(0, 1);

  if (humedad > UMBRAL_HUMEDAD) {
    lcd.print("REGAR           ");

    Serial.println("Suelo seco: se recomienda regar");

    digitalWrite(PIN_RELE, LOW);
  } else {
    lcd.print("NO REGAR        ");

    Serial.println("Suelo humedo: no es necesario regar");

    digitalWrite(PIN_RELE, HIGH);
  }

  Serial.println("------------------------------");

  delay(500);
}